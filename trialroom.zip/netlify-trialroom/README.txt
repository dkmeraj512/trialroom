NETLIFY DEPLOY (GitHub se, sabse aasan)
1. Is poore folder ko ek naye GitHub repository mein upload karein.
2. Netlify > Add new site > Import from Git > wahi repository chunein. Build settings ko jaisa hai waisa rehne dein.
3. Site settings > Environment variables mein daalein:
     ADMIN_PASSWORD = koi mazboot password
     AI_API_KEY     = aapke AI try-on provider ki key   (optional: baad mein admin panel se bhi daal sakte hain)
4. Deploy hone ke baad: https://aapki-site.netlify.app  (customer)  aur  https://aapki-site.netlify.app/#admin  (admin)
