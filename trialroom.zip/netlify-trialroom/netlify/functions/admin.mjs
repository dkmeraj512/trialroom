import crypto from 'node:crypto';
import { getSettings, getResults, today, json, isAdmin, makeToken, meta, images } from './_lib.mjs';
import { providers } from './_providers.mjs';

export default async req => {
  const url = new URL(req.url), path = url.pathname.replace('/api/admin/', ''), m = req.method;

  if (path === 'login' && m === 'POST') {
    const { password = '' } = await req.json().catch(() => ({}));
    const real = process.env.ADMIN_PASSWORD || '';
    const a = crypto.createHash('sha256').update(password).digest(), b = crypto.createHash('sha256').update(real).digest();
    return real && crypto.timingSafeEqual(a, b) ? json({ token: makeToken() }) : json({ error: 'Wrong password' }, 401);
  }
  if (!isAdmin(req)) return json({ error: 'Login required' }, 401);

  const s = await getSettings(), results = await getResults();

  if (path === 'stats') return json({ total: results.length, today: results.filter(r => r.date === today()).length, dailyLimit: s.dailyLimit });

  if (path === 'settings' && m === 'GET') {
    const { apiKey, ...rest } = s; // never send the key back
    return json({ ...rest, hasApiKey: !!(process.env.AI_API_KEY || apiKey), keyFromEnv: !!process.env.AI_API_KEY, providers: Object.keys(providers) });
  }
  if (path === 'settings' && m === 'PUT') {
    const b = await req.json();
    if (typeof b.shopName === 'string') s.shopName = b.shopName.slice(0, 60);
    if (typeof b.logo === 'string' && b.logo.length < 1e6) s.logo = b.logo;
    if (Number.isFinite(+b.dailyLimit)) s.dailyLimit = Math.max(0, +b.dailyLimit);
    if (providers[b.provider]) s.provider = b.provider;
    if (b.apiKey) s.apiKey = b.apiKey;
    await meta().setJSON('settings', s);
    return json({ ok: true });
  }

  if (path === 'results' && m === 'GET') return json([...results].reverse().slice(0, 200));

  if (path.startsWith('results') && m === 'DELETE') {
    const one = path.split('/')[1];
    const cutoff = Date.now() - (+url.searchParams.get('olderThanDays') || 0) * 864e5;
    const doomed = results.filter(r => (one ? r.id === one : r.createdAt < cutoff));
    await Promise.all(doomed.map(r => images().delete(r.file).catch(() => {})));
    await meta().setJSON('results', results.filter(r => !doomed.includes(r)));
    return json({ ok: true });
  }
  return json({ error: 'Not found' }, 404);
};
export const config = { path: '/api/admin/*' };
